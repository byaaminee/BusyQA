package assignment_Yaaminee;

public class Asgmt1_2_SumOfNums {

	public static void main(String[] args) {
		
		//Question: Write a Java program to print the sum of two numbers.

		int num1 = 4;
		int num2 = 36;
		
		int sum = num1 + num2;
		
		System.out.println("Sum of " + num1 + ", "+ num2);
		System.out.println(num1+ " + " + num2 + " = " +sum);

	}
}
