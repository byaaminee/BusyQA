package assignment_Yaaminee;

public class Asgmt1_1_PrintHello {

	public static void main(String[] args) {
		
		//Question: Java program to print Hello on screen and then print your name on a separate line.​
		
		System.out.println("Hello");
		System.out.println("Yaaminee");

	}

}
