package assignment_Yaaminee;

public class Asgmt1_3_Swap2Nums {

	public static void main(String[] args) {
		
		//Write a program to swap two numbers
		
		int a = 10;
		int b = 20;
		
		int c;
		
		System.out.println("Before swap: a = "+ a + ", b = "+ b);
		
		c = a;
		a = b;
		b = c;
		
		
		System.out.println("After swap: a = " + a + ", b = " + b);

	}

}
